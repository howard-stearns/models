// Here you can put a script that will be run by an assignment-client (AC)
// For examples, please go to https://github.com/highfidelity/hifi/tree/master/script-archive/acScripts
// The directory named acScripts contains assignment-client specific scripts you can try.
